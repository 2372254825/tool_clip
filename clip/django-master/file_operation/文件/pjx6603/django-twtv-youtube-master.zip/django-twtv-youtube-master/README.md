# django-twtv-youtube
django开发的一个台湾 TVyoutube 视频播放站（学习）

### 说明

* 1.本代码只作为学习django使用
* 2.代码主要为了熟悉django的template view  class url等简单功能
* 3.本代码参考《django 架站16课堂》第6章，用于学习


### 样例
![img](https://github.com/Roddy1219/django-twtv-youtube/blob/master/static/images/tv_img.png)
