from django.apps import AppConfig


class ApptvConfig(AppConfig):
    name = 'apptv'
